package com.example.ashesiasalivinglab;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class zoomlionLoginPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zoomlion_login_page);
    }
}
