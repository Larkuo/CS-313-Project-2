package com.example.ashesiasalivinglab;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class businessOnCampusPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business_on_campus_page);
    }
}
